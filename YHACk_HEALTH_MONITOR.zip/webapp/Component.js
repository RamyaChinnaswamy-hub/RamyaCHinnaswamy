sap.ui.define(["sap/ui/generic/app/AppComponent"], function (AppComponent) {
	return AppComponent.extend("YHACK.YHACk_HEALTH_MONITOR.Component", {
		metadata: {
			"manifest": "json"
		}
	});
});